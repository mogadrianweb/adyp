# Contexto e instrucciones para rediseñar ADYP

## Qué es `index.html`

El archivo `index.html` que acompaña a esta guía es una **copia independiente del frontend que estaba publicado**, preparada como referencia para analizarlo y rediseñarlo. **No es la web original en producción, no es el repositorio de código fuente y no contiene el backend ni la base de datos.** No lo publiques ni lo uses para sobrescribir la web original.

**Web original visible (solo para consultar el diseño):** [https://adisfrutarypunto.alwaysdata.net/](https://adisfrutarypunto.alwaysdata.net/).

**Copia pública del HTML para analizar:** [https://adisfrutarypunto.alwaysdata.net/testdesign/index.html](https://adisfrutarypunto.alwaysdata.net/testdesign/index.html). Ambas URL son solo de lectura para la IA: no debe iniciar sesión, editar ni publicar cambios. La copia tiene `noindex`, pero eso no es una medida de privacidad.

Se tomaron el HTML activo y sus recursos frontend locales; los módulos de JavaScript (incluidas las pantallas que la web cargaba por rutas) se agruparon dentro del HTML, al igual que las hojas de estilo y las fuentes. Por eso el JavaScript es el bundle compilado de producción, no los componentes fuente originales de React. Los comentarios dentro del bundle marcan algunos módulos, pero no son importaciones de archivos externos.

La copia incorpora además un filtro intencional de imágenes: no incluye fotos reales de quedadas ni de socios y bloquea imágenes de contenido que vengan de rutas/URLs; mantiene la marca y las imágenes necesarias de Google Maps. Las vistas temporales `Blob` de archivos elegidos durante el uso pueden seguir apareciendo. Esta diferencia es deliberada y no debe interpretarse como el comportamiento visual original de las fotos.

## Cómo funciona la aplicación

- Es una **aplicación de una sola página (SPA)** hecha con React y React Router. El HTML contiene el nodo `#root`; React dibuja las pantallas y actualiza la vista al navegar entre rutas.
- El frontend está empaquetado para producción con bundles con hash (estructura de build de Vite). Las rutas y estados de la interfaz están en JavaScript; los estilos están en CSS.
- Si no hay sesión, la aplicación muestra el acceso (`/entrada`) y el flujo para solicitar unirse (`/unirme`); el resto de rutas privadas redirige al acceso. Con sesión, carga datos del servidor y muestra estados de carga o error con opción de reintentar.
- En escritorio hay navegación superior; en móvil, una barra de navegación inferior fija. La distribución es responsive y la app tiene estados de botones, formularios, pestañas, filtros, avisos, modales y pantallas vacías/cargando/error.

### Rutas principales identificadas

| Ruta | Función general |
|---|---|
| `/` | Inicio de la comunidad y acceso a próximas quedadas, agenda y otras secciones. |
| `/entrada` | Inicio de sesión/acceso. |
| `/unirme` | Asistente de solicitud de alta para quien todavía no tiene sesión. |
| `/agenda` | Agenda/listado de quedadas, con navegación a sus detalles y al mapa. |
| `/mapa` | Mapa de quedadas; requiere la librería de Google Maps. |
| `/quedada/:id` | Detalle de una quedada. Incluye los flujos relacionados con plazas, inscripción y lista de espera según el estado y permisos. |
| `/quedada/nueva` | Propuesta de una quedada. La aplicación la presenta como un flujo superpuesto a la pantalla anterior y contempla permisos/estado del socio. |
| `/mis` | Quedadas de la persona usuaria, organizadas en pestañas/estados. |
| `/comunidad` | Grupos de comunidad por zona y afición. |
| `/perfil` | Perfil y opciones de cuenta. |
| `/moderacion` | Herramientas de moderación. |
| `/admin/*` | Panel de administración, con resumen y secciones `altas`, `socios`, `quedadas`, `auditoria`, `ajustes` y `datos`. |

La tabla describe la función general que se observa en el frontend; los permisos, datos y acciones definitivas los decide el servidor.

## Cómo está conectado

- El frontend llama a endpoints del mismo dominio, entre ellos `/api/auth.php`, `/api/eventos.php` y `/api/foto.php`. Ahí viven la autenticación, los datos/acciones de eventos y las operaciones de fotos. **Esos endpoints y sus reglas no están dentro de `index.html`.**
- Los datos reales requieren el servidor y la sesión correspondiente. Abrir el archivo con `file://` no convierte la web en una app offline ni da acceso a la API.
- Google Maps se carga desde Google y requiere conexión y la configuración de API de la web. No copies ni publiques claves o credenciales al documentar el rediseño.
- El HTML mantiene el enlace al manifiesto `/manifest.webmanifest`. La instalación PWA y las cabeceras de seguridad dependen también del hosting.
- La copia ajusta la CSP **dentro del HTML** para permitir sus scripts inline. Si se sirviera bajo las cabeceras HTTP originales, esas cabeceras podrían seguir bloqueándolos. No se ha cambiado la configuración del servidor.

## Guía visual y de interacción

- Marca: **ADYP · A disfrutar y punto**. La base visual actual usa una paleta cálida crema/papel, tinta oscura, turquesa/verde azulado y ámbar, con acentos de estado (coral, verde, aviso y error).
- Tipografías locales: familias Fraunces, Plus Jakarta Sans y Outfit; los iconos de interfaz son principalmente SVG.
- CSS define tokens para color, espacios, radios, sombras, tipografía y anchura de contenido. Las tarjetas, chips, inputs, botones, estados de foco y mensajes comparten esos tokens.
- Los enlaces de navegación usan rutas del cliente. Los botones pueden abrir diálogos, enviar formularios, cambiar pestañas/filtros, confirmar acciones o mostrar avisos. Conserva esos comportamientos, no solo su aspecto.
- Los estados de plazas, límites, espera, permisos, carga, error, vacío y confirmación forman parte de los flujos. No los elimines aunque una captura muestre solo el estado normal.
- Está enlazada la **capa móvil v2 activa**. Existe material/estilo móvil v1 anterior que fue rechazado y no forma parte de esta copia. No lo vuelvas a importar ni reintroduzcas estilos globales que agranden o cambien indiscriminadamente botones, iconos, chips, inputs o ventanas. La v2 ajusta paneles concretos; los demás diálogos deben conservar su comportamiento salvo que el nuevo diseño se apruebe expresamente.

## Límites del rediseño

1. Trabaja solo sobre una **copia de esta exportación**. No publiques ni edites la web original.
2. El objetivo es rediseñar la interfaz completa, pero mantener las rutas, la lógica de navegación, los permisos, la validación, los formularios y los flujos existentes.
3. No cambies API, backend, base de datos, autenticación ni reglas de negocio. No inventes endpoints o datos si no aparecen en el frontend.
4. No conviertas la SPA en una maqueta estática ni sustituyas interacciones por botones decorativos. Si refactorizas, demuestra qué flujo mantiene cada control.
5. No incluyas fotos reales de socios ni de quedadas. Usa las imágenes de marca/mapa permitidas o placeholders neutros aprobados.
6. Mantén idioma español, identidad ADYP, navegación accesible, etiquetas/roles `aria`, foco visible y diseño usable con teclado y lector de pantalla.
7. Revisa móvil y escritorio por separado. Conserva una navegación móvil clara y respeta áreas seguras/notch; no ocultes controles importantes bajo la barra inferior.
8. No divulgues claves, contraseñas ni datos personales que pudieran aparecer en el bundle o en datos cargados desde el servidor.
9. Antes de dar por terminado el trabajo, enumera qué cambiaste y prueba acceso, navegación, agenda, detalle/inscripción, propuesta, comunidad, perfil, moderación/admin (según permisos), formularios, modales y estados de error/carga. Si la API no está disponible en el entorno de prueba, indícalo en vez de inventar que funcionó.

## Prompt listo para copiar a otra IA

Este prompt es autosuficiente y está pensado para una IA externa: no tendrá acceso a este workspace, a archivos locales ni a tu hosting. No dependas de documentos adjuntos. Su única referencia es el enlace público indicado abajo; úsalo solo para lectura y análisis, sin iniciar sesión, desplegar ni modificar nada.

```text
Actúa como especialista senior en UX/UI, diseño visual y desarrollo frontend. Quiero que analices mi web ADYP completa, propongas varios diseños y construyas un ejemplo completo e interactivo para poder comprobarlos antes de aprobar un rediseño.

FUENTES QUE DEBES ANALIZAR
- Web original visible (solo para observar el diseño en producción): https://adisfrutarypunto.alwaysdata.net/
- Copia pública autónoma del HTML de referencia: https://adisfrutarypunto.alwaysdata.net/testdesign/index.html
- No hay otros archivos disponibles: trabaja solo con este prompt y esas URL públicas. Usa la web original para observar la experiencia visible y la copia HTML como referencia adicional; si solo puedes abrir una, indícalo.
- Analiza el diseño que realmente puedas observar. Si puedes inspeccionar el código fuente de la copia HTML, revisa también HTML, CSS y scripts; si solo puedes ver páginas renderizadas, basa el análisis en lo visible y señala qué no pudiste verificar. No afirmes haber leído código, rutas o estados que no hayas podido observar.

QUÉ REPRESENTA EL HTML
Es una copia independiente del frontend publicado, preparada como referencia. No es el repositorio fuente original ni incluye el backend, la base de datos o las reglas completas del servidor. El frontend es una SPA compilada con React/React Router; los bundles locales, estilos y fuentes están inlineados. La API PHP y Google Maps siguen siendo dependencias externas. La copia no contiene fotos reales de quedadas o socios y filtra imágenes de contenido. No la sobrescribas ni publiques cambios en la web original.

CONTEXTO VISUAL CONOCIDO
- Marca: ADYP · A disfrutar y punto. Mantén el idioma español.
- La interfaz existente usa una base cálida tipo crema/papel, tinta oscura, turquesa/verde azulado y ámbar, con colores de estado; las fuentes frontend incluyen Fraunces, Plus Jakarta Sans y Outfit.
- La web tiene navegación superior en escritorio y navegación inferior fija en móvil. La capa móvil activa es v2; no recuperes la versión móvil v1 rechazada ni apliques cambios globales indiscriminados a controles y diálogos.
- Conserva la personalidad de comunidad de quedadas. Puedes proponer estilos premium/profesionales alternativos, pero explica cómo siguen siendo reconocibles como ADYP.

OBJETIVO
Rediseña por completo la capa visual de ADYP con elementos modernos, premium y profesionales: una app limpia, coherente, cuidada y fácil de usar, diseñada primero para móvil y tablet. Puedes cambiar el estilo, la composición y los componentes visuales; no cambies ni elimines la funcionalidad, los recorridos, las rutas, las validaciones, los permisos ni las reglas existentes. Quiero varios ejemplos visuales funcionales que pueda recorrer y comparar en un único `index.html`; no una imagen estática ni solo una propuesta escrita. El archivo debe incluir también, dentro de la propia página, el prompt completo usado para generarlo.

FASE 1 — AUDITORÍA ANTES DE DISEÑAR
1. Haz un inventario de las rutas y funciones observables: /, /entrada, /unirme, /agenda, /mapa, /quedada/:id, /quedada/nueva, /mis, /comunidad, /perfil, /moderacion y /admin/* (resumen, altas, socios, quedadas, auditoria, ajustes y datos).
2. Describe navegación, formularios, controles, modales, estados, permisos y flujos que encuentres. Separa lo confirmado en el frontend de lo que no se pueda comprobar sin backend.
3. Identifica también escritorio, móvil, estilos activos y la capa móvil v2. No recuperes la capa v1 rechazada.

FASE 2 — PROPUESTAS VISUALES COMPLETAS
Presenta hasta tres conceptos visuales claramente diferenciados, todos con acabado premium y profesional. Diseña mobile-first para teléfono y tablet (vertical y horizontal); adapta escritorio solo como tamaño secundario. Para cada concepto especifica nombre, objetivo, paleta, tipografías, jerarquía, espaciado, componentes, navegación táctil, tarjetas, formularios, modales y microinteracciones.
- Cada concepto debe cubrir TODAS las pantallas y tipos de interfaz relevantes, no únicamente la página de inicio.
- Incluye una tabla comparativa y, si tu entorno lo permite, vistas previas o capturas para teléfono y tablet de cada propuesta; añade escritorio como referencia secundaria.
- Diseña controles cómodos al tacto, respeta áreas seguras/notch, mantiene foco visible y legibilidad, y evita que barras fijas tapen contenido.
- Conserva la identidad ADYP y su idioma español; puedes modernizar libremente el estilo visual, pero cualquier cambio de marca debe presentarse como alternativa, no imponerse.

FASE 3 — EJEMPLO INTERACTIVO PARA COMPROBAR LOS DISEÑOS
Construye un prototipo navegable y completo para revisar las propuestas:
- El entregable principal debe ser **un único archivo autónomo `index.html`**, guardado en una carpeta nueva. Incluye dentro del mismo HTML las propuestas visuales y el prototipo completo; no dependas de archivos separados para que funcione.
- Crea una galería/selector para comparar los conceptos en las mismas rutas y pantallas. Cada propuesta debe tener ejemplos completos y navegables, no solo una portada. Si no puedes alternar los diseños dentro del mismo prototipo, explica la limitación y crea el mejor comparador posible dentro de ese `index.html`.
- Añade dentro del propio `index.html` una sección o pestaña **«Prompt completo»** con el texto íntegro de este prompt, visible y copiable mediante un botón «Copiar prompt». No lo dejes únicamente en un archivo Markdown aparte.
- Incluye todas las rutas principales y las secciones administrativas descritas, con navegación funcional entre pantallas.
- Implementa interacciones demostrativas: navegación, filtros, pestañas, formularios con validación, modales, avisos y estados de carga, vacío, error y confirmación. Usa datos ficticios de demostración, claramente identificados; no conectes ni alteres la API real.
- Mantén los flujos de acceso/solicitud de alta, agenda, detalle e inscripción/lista de espera, propuesta de quedada, mis quedadas, comunidad, perfil, moderación y administración según el frontend de referencia.
- Prioriza vistas responsive reales para móvil y tablet, tanto en vertical como en horizontal; escritorio es secundario. Comprueba tamaños táctiles cómodos, áreas seguras, navegación fija, lectura y ausencia de desbordamiento o contenido tapado.
- No añadas fotos reales de socios o quedadas. Usa placeholders neutros, SVG o recursos de marca permitidos. No dependas de Google Maps en el prototipo: representa el mapa con una vista demostrativa local y deja clara esa limitación.

RESTRICCIONES
- Trabaja en una copia/proyecto nuevo. No modifiques ni publiques sobre la web original.
- Puedes cambiar libremente el diseño visual: estilo, paleta, tipografía, composición y componentes. Mantén intactas la funcionalidad, la navegación y los recorridos que existen; no elimines ni conviertas funciones reales en elementos decorativos.
- No cambies rutas, API, backend, base de datos, autenticación, permisos, validaciones ni reglas de negocio. El prototipo puede simular respuestas localmente, pero no debe fingir que conectó con producción.
- No elimines controles ni estados existentes para simplificar la maqueta. Conserva accesibilidad, etiquetas y roles aria, foco visible y uso por teclado.
- No introduzcas CSS global que altere indiscriminadamente todos los botones, chips, iconos, inputs o diálogos. Respeta la capa móvil v2 activa; no uses la v1 retirada.
- No muestres, copies ni publiques credenciales, claves ni datos personales que pudieran aparecer en el bundle.

ENTREGA PRINCIPAL — UN SOLO `index.html`
- Guarda el resultado como `adyp-diseno-premium/index.html` (o nombre parecido) en una carpeta nueva, separado del HTML de referencia.
- Haz que sea autónomo: HTML, CSS y JavaScript inline; usa SVG/data URI/placeholders locales y evita dependencias externas/CDN. Debe abrirse directamente en el navegador desde el archivo descargado, sin instalación ni compilación.
- Dentro de ese mismo `index.html` incluye la galería de propuestas, el ejemplo funcional completo y el panel «Prompt completo» con todo este prompt y botón para copiarlo.
- No edites, reemplaces, subas ni publiques ningún archivo del sitio existente. No uses SSH/SFTP ni accedas al hosting. Tanto la web original `https://adisfrutarypunto.alwaysdata.net/` como la copia `https://adisfrutarypunto.alwaysdata.net/testdesign/index.html` son referencias de solo lectura.
- Proporciona el archivo `index.html` como enlace/archivo descargable visible para mí. Si tu entorno lo permite, añade también un enlace de vista previa; pero el entregable obligatorio es ese HTML descargable. No me digas solo que está listo: muestra dónde descargarlo.
- Si la demo usa datos simulados o no puede ejecutar algo por falta de backend/Google Maps, indícalo claramente dentro del prototipo y en la respuesta final.

VERIFICACIÓN FINAL
Antes de entregar, prueba las rutas principales, las interacciones y los estados; comprueba escritorio y móvil. Resume qué incluye cada concepto, cuál recomiendas y por qué, qué probaste, qué no pudiste probar y los enlaces de preview/descarga.
```
