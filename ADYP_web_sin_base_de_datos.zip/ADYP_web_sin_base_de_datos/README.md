# ADYP — archivos web descargados (sin base de datos)

Esta carpeta contiene una copia de los archivos públicos del directorio `www` de `adisfrutarypunto.alwaysdata.net`, descargada por SFTP en modo de solo lectura el 9 de octubre de 2026. No se ha editado ni publicado ningún archivo en el hosting.

## Incluido

- `www/index.html`, configuración pública del servidor y manifiesto PWA.
- Código frontend compilado (JavaScript/CSS), fuentes e iconos.
- Código fuente PHP de los endpoints en `www/api/`.
- APKs públicos que estaban en `www/apps/`.
- Imágenes de marca y recursos genéricos de categorías, subcategorías y zonas.
- `INSTRUCCIONES_PARA_IA.md`, con la guía y el prompt de diseño actualizado.

## Excluido o saneado por privacidad y seguridad

- Base de datos, volcados de base de datos y configuración externa `adyp_db.php`.
- Carpetas de copias de seguridad fuera de `www`.
- `www/uploads/`, la copia `www/testdesign/` y las imágenes `www/img/inicio-*` y `www/img/grupos-*`.
- El valor de la clave de Google Maps, sustituido por `GOOGLE_MAPS_API_KEY_REDACTED` en `www/assets/Mapa-DASn7RI2.js`.
- Datos personales de ejemplo incrustados en los bundles compilados: las listas locales de socios/solicitudes se han vaciado y los ejemplos de teléfono/correo se han neutralizado.

## Limitaciones

No es una copia restaurable completa ni una aplicación autónoma. Los endpoints PHP requieren la base de datos y la configuración externa que se excluyeron. Google Maps requiere una clave configurada por separado. Se conservaron rutas y archivos del frontend; no se modificó el sitio publicado.
